<?php

namespace App\Http\Controllers;

use App\Models\Anak;
use App\Models\Desa;
use App\Models\Faskes;
use App\Models\Sekolah;
use App\Models\User;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index(Request $request): View
    {
        $user = $request->user();

        return $user->isAdmin()
            ? $this->adminDashboard($request)
            : $this->sekolahDashboard($user);
    }

    private function adminDashboard(Request $request): View
    {
        $desaId = $request->integer('desa_id') ?: null;

        $desas = Desa::orderBy('nama_desa')->get();

        $totalSekolah = Sekolah::when($desaId, fn ($q) => $q->where('desa_id', $desaId))->count();
        $totalGuru = (int) Sekolah::when($desaId, fn ($q) => $q->where('desa_id', $desaId))->sum('jumlah_guru');
        $totalSiswa = Anak::whereNotNull('sekolah_id')
            ->when($desaId, fn ($q) => $q->where('desa_id', $desaId))
            ->count();

        $totalFaskes = Faskes::when($desaId, fn ($q) => $q->where('desa_id', $desaId))->count();
        $totalAnakTerdata = Anak::when($desaId, fn ($q) => $q->where('desa_id', $desaId))->count();
        $totalStunting = Anak::stunting()->when($desaId, fn ($q) => $q->where('desa_id', $desaId))->count();

        // Rekap per desa untuk tabel & grafik
        $rekapPerDesa = Desa::withCount([
                'sekolahs',
                'anaks as total_siswa' => fn ($q) => $q->whereNotNull('sekolah_id'),
                'anaks as total_anak_terdata',
                'anaks as total_stunting' => fn ($q) => $q->where('status_stunting', 'Stunting'),
            ])
            ->withSum('sekolahs as total_guru', 'jumlah_guru')
            ->orderBy('nama_desa')
            ->get();

        return view('dashboard.admin', compact(
            'desas',
            'desaId',
            'totalSekolah',
            'totalGuru',
            'totalSiswa',
            'totalFaskes',
            'totalAnakTerdata',
            'totalStunting',
            'rekapPerDesa'
        ));
    }

    private function sekolahDashboard(User $user): View
    {
        $sekolah = $user->sekolah;
        $totalSiswa = $sekolah ? $sekolah->anaks()->count() : 0;

        return view('dashboard.sekolah', compact('sekolah', 'totalSiswa'));
    }
}
